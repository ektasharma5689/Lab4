package lab4;

enum Gender{
	Undefined,M,F;
}