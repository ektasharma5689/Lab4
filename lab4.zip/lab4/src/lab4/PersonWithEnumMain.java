package lab4;

	public class PersonWithEnumMain {

		public static void main(String[] args)
		{
			PersonwithEnum obj = new PersonwithEnum("Sara","Biswas",Gender.F,"9874082847");
			obj.display();
			
		}

	}

