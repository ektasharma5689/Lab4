package lab4;

	public class BalanceNotSufficientException extends Exception
	{
		BalanceNotSufficientException()
		{
			super();
			System.out.println("can not withdraw due to insufficient balance");
		}
	}

