package lab4;


	public class PersonMain {

		public static void main(String[] args) 
		{
			PersonwithEnum obj1 = new PersonwithEnum();
			obj1.setFirstName("Souree");
			obj1.setLastName("Biswas");
			obj1.setGender('F');
			System.out.println("Person Details.....\n_____________");
			System.out.println("First Name: "+obj1.getFirstName());
			System.out.println("Last Name: "+obj1.getLastName());
			System.out.println("Gender: "+obj1.getGender());
			
			PersonwithEnum obj2 = new PersonwithEnum("Rajat","Nagil",Gender.M,"123564879");
			System.out.println("Person Details.....\n_____________");
			
			System.out.println("First Name: "+obj2.getFirstName());
			System.out.println("Last Name: "+obj2.getLastName());
			System.out.println("Gender: "+obj2.getGender());
			System.out.println("Phonenumber:" + obj2.getPhonenumber());
		}

	}


